// Ladakh Trip Dashboard logic
const state = {data:null, editPins:false, map:null, markers:[], line:null, showDistance:true};

async function loadData() {
  // prefer localStorage edits first
  const edited = localStorage.getItem("ladakh_trip_json");
  if (edited) {
    try { return JSON.parse(edited); } catch(e) { console.warn("Bad local JSON, falling back", e); }
  }
  const res = await fetch('data/trip.json');
  return await res.json();
}

function fmtDate(d) {
  const dt = new Date(d);
  return dt.toLocaleDateString(undefined, {month:'short', day:'numeric'});
}

function nights(check_in, check_out) {
  const a = new Date(check_in);
  const b = new Date(check_out);
  return Math.round((b - a)/(1000*60*60*24));
}

function buildCountdown(firstDateStr) {
  const el = document.getElementById('countdown');
  const firstDate = new Date(firstDateStr);
  function tick() {
    const now = new Date();
    const diff = firstDate - now;
    if (diff <= 0) { el.textContent = "You're on the trip 🎉"; return; }
    const days = Math.floor(diff / (1000*60*60*24));
    const hours = Math.floor((diff / (1000*60*60)) % 24);
    el.textContent = `T-${days}d ${hours}h`;
  }
  tick(); setInterval(tick, 60000);
}

function makeFlights(flights) {
  const wrap = document.getElementById('flights');
  wrap.innerHTML = '<h3>Flights</h3>';
  flights.forEach(f => {
    const div = document.createElement('div');
    div.className = 'flight';
    const dep = new Date(f.when_local);
    const arr = new Date(f.arrive_local);
    div.innerHTML = `
      <div><strong>${f.airline} ${f.flight_no}</strong> • PNR ${f.pnr||''}</div>
      <div>${f.from.code} → ${f.to.code} • ${dep.toLocaleString()} → ${arr.toLocaleTimeString()}</div>
    `;
    wrap.appendChild(div);
  });
}

function makeTimeline(stays) {
  const tl = document.getElementById('timeline');
  tl.innerHTML = '';
  stays.forEach(s => {
    const card = document.createElement('div');
    card.className = 'timeline-card';
    card.innerHTML = `
      <div><strong>${s.property}</strong></div>
      <div class="dates">${fmtDate(s.check_in)} → ${fmtDate(s.check_out)} • ${nights(s.check_in, s.check_out)} night(s)</div>
      <div class="muted">${s.address||''}</div>
    `;
    tl.appendChild(card);
  });
}

function makeBudget(budget) {
  const tbl = document.getElementById('budget-table');
  tbl.innerHTML = '';
  const thead = document.createElement('thead');
  thead.innerHTML = `<tr><th>Item</th><th>Amount (${budget.currency})</th><th>Status</th></tr>`;
  tbl.appendChild(thead);
  const tb = document.createElement('tbody');
  budget.items.forEach((it, idx) => {
    const tr = document.createElement('tr');
    const amount = it.amount==null ? '' : it.amount;
    tr.innerHTML = `
      <td contenteditable="true" class="editable" data-section="budget" data-field="label" data-idx="${idx}">${it.label}</td>
      <td contenteditable="true" class="editable" data-section="budget" data-field="amount" data-idx="${idx}">${amount}</td>
      <td contenteditable="true" class="editable" data-section="budget" data-field="status" data-idx="${idx}">${it.status||''}</td>
    `;
    tb.appendChild(tr);
  });
  tbl.appendChild(tb);
}

function makeStaysTable(stays) {
  const tbl = document.getElementById('stays-table');
  tbl.innerHTML = '';
  const thead = document.createElement('thead');
  thead.innerHTML = '<tr><th>Property</th><th>Check-in</th><th>Check-out</th><th>Nights</th><th>Altitude (m)</th><th>Lat</th><th>Lng</th></tr>';
  tbl.appendChild(thead);
  const tb = document.createElement('tbody');
  stays.forEach((s, idx) => {
    const lat = s.coords?.lat ?? '';
    const lng = s.coords?.lng ?? '';
    const alt = s.altitude_m ?? '';
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td contenteditable="true" class="editable" data-section="stays" data-field="property" data-idx="${idx}">${s.property}</td>
      <td contenteditable="true" class="editable" data-section="stays" data-field="check_in" data-idx="${idx}">${s.check_in}</td>
      <td contenteditable="true" class="editable" data-section="stays" data-field="check_out" data-idx="${idx}">${s.check_out}</td>
      <td>${nights(s.check_in, s.check_out)}</td>
      <td contenteditable="true" class="editable" data-section="stays" data-field="altitude_m" data-idx="${idx}">${alt}</td>
      <td contenteditable="true" class="editable" data-section="stays" data-field="lat" data-idx="${idx}">${lat}</td>
      <td contenteditable="true" class="editable" data-section="stays" data-field="lng" data-idx="${idx}">${lng}</td>
    `;
    tb.appendChild(tr);
  });
  tbl.appendChild(tb);
}

function saveEdits(e) {
  if (!e.target.classList.contains('editable')) return;
  const el = e.target;
  const section = el.dataset.section;
  const field = el.dataset.field;
  const idx = Number(el.dataset.idx);
  const value = el.textContent.trim();
  if (section === 'budget') {
    state.data.budget.items[idx][field] = field==='amount' && value!=='' ? Number(value) : value;
  } else if (section === 'stays') {
    if (field === 'lat' || field === 'lng') {
      state.data.stays[idx].coords = state.data.stays[idx].coords || {};
      state.data.stays[idx].coords[field === 'lat' ? 'lat' : 'lng'] = value==='' ? null : Number(value);
    } else if (field === 'altitude_m') {
      state.data.stays[idx][field] = value==='' ? null : Number(value);
    } else {
      state.data.stays[idx][field] = value;
    }
    // re-render dependent views
    drawMap(state.data.stays);
    drawAltChart(state.data.stays);
    makeTimeline(state.data.stays);
  }
  localStorage.setItem('ladakh_trip_json', JSON.stringify(state.data));
}

async function geocodeIfNeeded(stay) {
  if (stay.coords && typeof stay.coords.lat === 'number' && typeof stay.coords.lng === 'number') return stay.coords;
  const q = encodeURIComponent(`${stay.property} ${stay.address || ''}`);
  const url = `https://nominatim.openstreetmap.org/search?q=${q}&format=json&limit=1`;
  try {
    const res = await fetch(url, {headers:{'Accept':'application/json'}});
    const js = await res.json();
    if (js && js.length>0) {
      const lat = Number(js[0].lat), lng = Number(js[0].lon);
      stay.coords = {lat, lng};
      return stay.coords;
    }
  } catch(e) {
    console.warn("Geocode failed for", stay.property, e);
  }
  return null;
}

function fitMap() {
  const group = new L.featureGroup(state.markers.map(m => m.marker));
  if (state.map && group.getLayers().length>0) state.map.fitBounds(group.getBounds().pad(0.25));
}

async function drawMap(stays) {
  if (!state.map) {
    state.map = L.map('map');
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 18, attribution: '&copy; OpenStreetMap'
    }).addTo(state.map);
  }
  // clear markers/line
  state.markers.forEach(m => m.marker.remove());
  state.markers = [];
  if (state.line) { state.line.remove(); state.line=null; }

  // ensure coords
  for (const s of stays) { await geocodeIfNeeded(s); }

  const coords = [];
  stays.forEach((s, idx) => {
    if (!s.coords) return;
    const marker = L.marker([s.coords.lat, s.coords.lng], {draggable: state.editPins});
    marker.addTo(state.map).bindPopup(`<strong>${s.property}</strong><br>${s.address||''}<br>${s.check_in} → ${s.check_out}`);
    marker.on('dragend', (ev) => {
      const pos = ev.target.getLatLng();
      s.coords = {lat: pos.lat, lng: pos.lng};
      // update table cells
      const rows = document.querySelectorAll('#stays-table tbody tr');
      const row = rows[idx];
      row.children[5].textContent = pos.lat.toFixed(6);
      row.children[6].textContent = pos.lng.toFixed(6);
      localStorage.setItem('ladakh_trip_json', JSON.stringify(state.data));
      drawRouteLabel();
    });
    state.markers.push({marker, stay: s});
    coords.push([s.coords.lat, s.coords.lng]);
  });

  if (coords.length>1) {
    state.line = L.polyline(coords, {color:'#3fb950'}).addTo(state.map);
  }
  fitMap();
  drawRouteLabel();
}

function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371; // km
  const toRad = (d) => d * Math.PI / 180;
  const dLat = toRad(lat2-lat1);
  const dLon = toRad(lon2-lon1);
  const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLon/2)**2;
  const c = 2*Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R*c;
}

function drawRouteLabel() {
  if (!state.showDistance) return;
  // Simple straight-line segment distances
  const labels = [];
  for (let i=0; i<state.markers.length-1; i++) {
    const a = state.markers[i].stay.coords;
    const b = state.markers[i+1].stay.coords;
    if (!a || !b) continue;
    const d = haversine(a.lat, a.lng, b.lat, b.lng);
    labels.push(`${state.markers[i].stay.property.split(' (')[0]} → ${state.markers[i+1].stay.property.split(' (')[0]}: ${d.toFixed(1)} km`);
  }
  const legend = document.querySelector('.legend');
  let p = legend.querySelector('.distances');
  if (!p) { p = document.createElement('div'); p.className='distances'; legend.appendChild(p); }
  p.textContent = labels.join('  •  ');
}

function drawAltChart(stays) {
  const ctx = document.getElementById('altChart');
  const labels = stays.map(s => s.property.split(' (')[0]);
  const data = stays.map(s => s.altitude_m || null);
  if (state.altChart) { state.altChart.destroy(); }
  state.altChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{label:'Sleep altitude (m)', data}]
    },
    options: {
      responsive:true,
      plugins:{legend:{display:false}},
      scales:{y:{ticks:{callback:(v)=>v+' m'}}}
    }
  });
}

function generateICS(data) {
  const lines = ['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Ladakh Trip//EN'];
  // Flights as events
  data.flights.forEach(f => {
    const dtStart = f.when_local.replace(/[-:]/g,'').replace(/\.\d{3}/,'').replace('+05:30','');
    const dtEnd = f.arrive_local.replace(/[-:]/g,'').replace(/\.\d{3}/,'').replace('+05:30','');
    lines.push('BEGIN:VEVENT');
    lines.push(`UID:${crypto.randomUUID()}@ladakh`);
    lines.push(`DTSTART:${dtStart}`);
    lines.push(`DTEND:${dtEnd}`);
    lines.push(`SUMMARY:${f.from.code}→${f.to.code} ${f.airline} ${f.flight_no}`);
    lines.push(`DESCRIPTION:PNR ${f.pnr||''}`);
    lines.push('END:VEVENT');
  });
  // Stays
  data.stays.forEach(s => {
    lines.push('BEGIN:VEVENT');
    lines.push(`UID:${crypto.randomUUID()}@ladakh`);
    lines.push(`DTSTART;VALUE=DATE:${s.check_in.replaceAll('-','')}`);
    lines.push(`DTEND;VALUE=DATE:${s.check_out.replaceAll('-','')}`);
    lines.push(`SUMMARY:Stay - ${s.property}`);
    lines.push(`LOCATION:${s.address||''}`);
    lines.push('END:VEVENT');
  });
  lines.push('END:VCALENDAR');
  return lines.join('\r\n');
}

function exportFile(name, content, mime) {
  const blob = new Blob([content], {type: mime});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
}

function bindControls() {
  document.getElementById('export-json').addEventListener('click', () => {
    exportFile('trip.json', JSON.stringify(state.data, null, 2), 'application/json');
  });
  document.getElementById('download-ics').addEventListener('click', () => {
    exportFile('ladakh-trip.ics', generateICS(state.data), 'text/calendar');
  });
  document.getElementById('reset-local').addEventListener('click', () => {
    localStorage.removeItem('ladakh_trip_json');
    location.reload();
  });
  document.getElementById('toggle-route').addEventListener('change', (e) => {
    if (state.line) e.target.checked ? state.line.addTo(state.map) : state.line.remove();
  });
  document.getElementById('toggle-distance').addEventListener('change', (e) => {
    state.showDistance = e.target.checked;
    drawRouteLabel();
  });
  document.getElementById('edit-pins').addEventListener('click', () => {
    state.editPins = !state.editPins;
    document.getElementById('edit-pins').textContent = state.editPins ? 'Done' : 'Edit pins';
    drawMap(state.data.stays);
  });
  document.body.addEventListener('input', saveEdits);
}

async function init() {
  state.data = await loadData();
  document.getElementById('trip-title').textContent = state.data.tripTitle || 'Ladakh Trip';
  buildCountdown(state.data.stays[0].check_in + "T00:00:00");
  makeFlights(state.data.flights);
  makeTimeline(state.data.stays);
  makeBudget(state.data.budget);
  makeStaysTable(state.data.stays);
  await drawMap(state.data.stays);
  drawAltChart(state.data.stays);
  bindControls();
}
init();
