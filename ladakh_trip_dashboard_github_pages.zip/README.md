# Ladakh Trip Dashboard (Static, GitHub Pages)

An all-in-one, **static** (no backend) trip dashboard for your Ladakh itinerary.
It shows a map + route, day-by-day timeline, sleep altitude chart, and a simple budget editor.
It also generates a calendar (.ics) you can import into Google Calendar.

## How to deploy on GitHub Pages

1. Create a new repo on GitHub, e.g. `ladakh-trip`.
2. Upload all files in this folder (or just drag-and-drop the ZIP).
3. Go to **Settings → Pages**, and set **Source** to `main` and **Branch** to `/root` (or `main` if that's the default).
4. Wait ~30 seconds. Your site will be live at `https://<your-username>.github.io/ladakh-trip/`.

> Tip: If you use a subfolder, ensure all paths are relative (`./assets/app.js`).

## Local edits

- All edits you make in the browser save to `localStorage`.
- Use **Export JSON** to download your edited data and commit it back to `data/trip.json` to make it permanent.
- Use **Reset edits** to discard local changes.

## Data sources & caveats

- Trip data was auto-filled from your booking emails.
- Coordinates are **auto-geocoded on first load** if missing (via OpenStreetMap Nominatim). You can drag pins to exact spots.
- **Altitudes are approximate**. Edit them in the Stays table if you have exact values (e.g., from GPS).

## Tech

- **Leaflet** for maps (OpenStreetMap tiles, no API key).
- **Chart.js** for the altitude sparkline.
- All JS runs client-side; safe for GitHub Pages.
